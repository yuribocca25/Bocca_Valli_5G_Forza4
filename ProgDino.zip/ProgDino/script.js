var character = document.getElementById("character");
var block = document.getElementById("block");
var counter = 0;

function jump() {
    //if per non far spammare il salto
    if (character.classList == "animate") { return }
    character.classList.add("animate");
    //rimuove la classe una volta finita l'animazione così
    //da poter saltae di nuovo
    setTimeout(function() {
        character.classList.remove("animate");
    }, 300);
}
//controlla se i blocchi si toccano e stoppa la partita
var checkDead = setInterval(function() {
    let characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"));
    let blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"));
    if (blockLeft < 20 && blockLeft > -20 && characterTop >= 130) {
        block.style.animation = "none";
        alert("Hai perso. Punteggio: " + Math.floor(counter / 100));
        counter = 0;
        block.style.animation = "block 1s infinite linear";
    } else {
        counter++;
        document.getElementById("scoreSpan").innerHTML = Math.floor(counter / 100);
    }
}, 10);