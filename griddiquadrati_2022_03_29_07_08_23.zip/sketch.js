function setup() {
  createCanvas(800, 1000);
}

function draw() {
  background(999);
}

function draw()
{
  square(30, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(30, 405, 55);
describe('white square with black outline in mid-right of canvas');
  
  //
  
  square(85, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 20, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 20, 55);
describe('white square with black outline in mid-right of canvas');

  //
  
  square(85, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 75, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 75, 55);
describe('white square with black outline in mid-right of canvas');
 
  //
  
  square(85, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 130, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 130, 55);
describe('white square with black outline in mid-right of canvas');
  
  //
  
  square(85, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 185, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 185, 55);
describe('white square with black outline in mid-right of canvas');
 
  //
  
  square(85, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 240, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 240, 55);
describe('white square with black outline in mid-right of canvas');

  //
  
  square(85, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 295, 55);
describe('white suare with black outline in mid-right of canvas');
  square(360, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 295, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 295, 55);
describe('white square with black outline in mid-right of canvas');

  //
  
  square(85, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 350, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 350, 55);
describe('white square with black outline in mid-right of canvas');
  
  //
  
  square(85, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(140, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(195, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(250, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(305, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(360, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(415, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(470, 405, 55);
describe('white square with black outline in mid-right of canvas');
  square(525, 405, 55);
describe('white square with black outline in mid-right of canvas');
  
}